import { useCallback, useEffect, useState } from 'react';
import data from './MOCK_DATA.json';

export default function Problem6() {
  const [cars, setCars] = useState(data);
  const [selectedCar, setSelectedCar] = useState(null);
  const [formValues, setFormValues] = useState({
    vin: '',
    make: '',
    model: '',
    year: '',
    color: ''
  });

 
  useEffect(() => {
    if (selectedCar) {
      setFormValues({
        vin: selectedCar.vin,
        make: selectedCar.make,
        model: selectedCar.model,
        year: selectedCar.year,
        color: selectedCar.color
      });
    } else {
      setFormValues({
        vin: '',
        make: '',
        model: '',
        year: '',
        color: ''
      });
    }
  }, [selectedCar]);

 
  const handleSaveOrUpdate = useCallback(() => {
    setCars((prevCars) => {
      if (selectedCar) {
        return prevCars.map((car) =>
          car.vin === selectedCar.vin ? { ...formValues } : car
        );
      }
      return [...prevCars, { ...formValues }];
    });
    setSelectedCar(null); 
  }, [formValues, selectedCar]);

 
  const handleClear = useCallback(() => {
    setFormValues({
      vin: '',
      make: '',
      model: '',
      year: '',
      color: ''
    });
    setSelectedCar(null); 
  }, []);


  const handleEdit = useCallback((car) => {
    setSelectedCar(car);
  }, []);

  const handleDelete = useCallback((vin) => {
    setCars((prevCars) => prevCars.filter((car) => car.vin !== vin));
    if (selectedCar && selectedCar.vin === vin) {
      handleClear(); 
    }
  }, [selectedCar, handleClear]);

  return (
    <>
     
      <div>
        {['vin', 'make', 'model', 'year', 'color'].map((field) => (
          <div key={field} style={{ display: 'block' }}>
            {field.charAt(0).toUpperCase() + field.slice(1)}:{' '}
            <input
              type="text"
              value={formValues[field]}
              onChange={(e) =>
                setFormValues({ ...formValues, [field]: e.target.value })
              }
            />
          </div>
        ))}
        <button type="button" onClick={handleSaveOrUpdate}>
          {selectedCar ? 'Update' : 'Save'}
        </button>
        <button type="button" onClick={handleClear}>
          Clear
        </button>
      </div>

      
      <div className="table-container">
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>VIN</th>
              <th>Make</th>
              <th>Model</th>
              <th>Year</th>
              <th>Color</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {cars.map((car) => (
              <tr key={car.vin}>
                <td>{car.vin}</td>
                <td>{car.make}</td>
                <td>{car.model}</td>
                <td>{car.year}</td>
                <td>{car.color}</td>
                <td>
                  <button type="button" onClick={() => handleEdit(car)}>
                    Edit
                  </button>
                  <button type="button" onClick={() => handleDelete(car.vin)}>
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}

import React, { useEffect, useRef, useState } from 'react';
import Loading from './Problem5Components/Loading';

export default function Problem5() {
  const [isLoading, setIsLoading] = useState(true);
  const [isIdle, setIsIdle] = useState(true);
  const idleTimeoutRef = useRef(null);

  useEffect(() => {
   
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    
    const handleUserActivity = () => {
      clearTimeout(idleTimeoutRef.current);
      setIsIdle(false);

    
      idleTimeoutRef.current = setTimeout(() => {
        setIsIdle(true);
      }, 800);
    };

   
    document.addEventListener('keydown', handleUserActivity);

    return () => {
     
      document.removeEventListener('keydown', handleUserActivity);
    };
  }, []);

  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div style={{ display: 'block' }}>
            Input: <input type='text' />
            <p>User is {isIdle ? 'idle' : 'typing'}...</p>
          </div>
        </>
      )}
    </>
  );
}
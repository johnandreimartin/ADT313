import React, { useReducer, useState } from 'react';
import data from './problem8mock_data.json';

const initialState = {
  foods: data.map((food, index) => ({ ...food, id: index + 1 })), // Adding unique IDs to initial data
  selected: null,
};

function reducer(state, action) {
  switch (action.type) {
    case 'CREATE':
      state.foods.push(action.payload);
      return {
        ...state,
      };
    case 'READ':
      return {
        ...state,
        selected: action.payload,
      };
    case 'UPDATE':
      return {
        ...state,
        foods: state.foods.map(food => 
          food.id === action.payload.id ? action.payload : food
        ),
      };
    case 'DELETE':
      return {
        ...state,
        foods: state.foods.filter(food => food.id !== action.payload),
      };
    case 'CLEAR':
      return {
        ...state,
        selected: null,
      };
    default:
      return state;
  }
}

export default function Problem8() {
  const [state, dispatch] = useReducer(reducer, initialState);
  const [formData, setFormData] = useState({
    food_name: '',
    price: '',
    expiration_date: '',
    calories: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({ ...prevData, [name]: value }));
  };

  const handleSave = () => {
    if (state.selected) {
      dispatch({ type: 'UPDATE', payload: { ...formData, id: state.selected.id } });
    } else {
      dispatch({ type: 'CREATE', payload: { ...formData, id: state.foods.length + 1 } });
    }
    setFormData({ food_name: '', price: '', expiration_date: '', calories: '' });
    dispatch({ type: 'CLEAR' });
  };

  const handleClear = () => {
    setFormData({ food_name: '', price: '', expiration_date: '', calories: '' });
    dispatch({ type: 'CLEAR' });
  };

  const handleEdit = (food) => {
    setFormData(food);
    dispatch({ type: 'READ', payload: food });
  };

  const handleDelete = (id) => {
    dispatch({ type: 'DELETE', payload: id });
  };

  return (
    <>
      <div>
        <div style={{ display: 'block' }}>
          Food Name:{' '}
          <input
            type='text'
            name='food_name'
            value={formData.food_name}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Price:{' '}
          <input
            type='text'
            name='price'
            value={formData.price}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Expiration Date:{' '}
          <input
            type='text'
            name='expiration_date'
            value={formData.expiration_date}
            onChange={handleInputChange}
          />
        </div>
        <div style={{ display: 'block' }}>
          Calories:{' '}
          <input
            type='text'
            name='calories'
            value={formData.calories}
            onChange={handleInputChange}
          />
        </div>
        <button type='button' onClick={handleSave}>Save</button>
        <button type='button' onClick={handleClear}>Clear</button>
      </div>
      <div className='table-container'>
        <table style={{ width: '100%' }}>
          <thead>
            <tr>
              <th>Food Name</th>
              <th>Price</th>
              <th>Expiration Date</th>
              <th>Calories</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody style={{ textAlign: 'center' }}>
            {state.foods.map((food) => (
              <tr key={food.id} onClick={() => handleEdit(food)}>
                <td>{food.food_name}</td>
                <td>{food.price}</td>
                <td>{food.expiration_date}</td>
                <td>{food.calories}</td>
                <td>
                  <button type='button' onClick={() => handleEdit(food)}>Edit</button>
                  <button type='button' onClick={() => handleDelete(food.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}